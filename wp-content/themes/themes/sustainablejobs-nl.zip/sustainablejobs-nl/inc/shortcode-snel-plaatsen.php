<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [sj_snel_plaatsen]
 * Snel een vacature plaatsen via e-mailadres + URL.
 */
add_shortcode('sj_snel_plaatsen', 'sj_snel_plaatsen_shortcode');

function sj_snel_plaatsen_shortcode(): string {

    $success = false;
    $errors  = [];

    if (
        $_SERVER['REQUEST_METHOD'] === 'POST' &&
        isset($_POST['sj_sp_nonce']) &&
        wp_verify_nonce($_POST['sj_sp_nonce'], 'sj_snel_plaatsen')
    ) {
        $email = sanitize_email($_POST['sp_email']  ?? '');
        $url   = esc_url_raw($_POST['sp_url']       ?? '');

        if (!is_email($email)) $errors[] = 'Vul een geldig e-mailadres in.';
        if (!$url)             $errors[] = 'Vul de URL van de vacature in.';

        if (empty($errors)) {
            $body  = "Nieuwe snel-plaatsen aanvraag:\n\n";
            $body .= "E-mail: $email\n";
            $body .= "Vacature URL: $url\n";

            wp_mail(
                'support@sustainablejobs.nl',
                'Snel plaatsen aanvraag',
                $body,
                ['Content-Type: text/plain; charset=UTF-8']
            );

            /* Sla op als CPT */
            $post_id = wp_insert_post([
                'post_title'  => $url,
                'post_status' => 'pending',
                'post_type'   => 'sj_vacature',
                'post_author' => 0,
            ]);

            if ($post_id && !is_wp_error($post_id)) {
                update_post_meta($post_id, '_sj_email',        $email);
                update_post_meta($post_id, '_sj_pakket',       'Snel plaatsen');
                update_post_meta($post_id, '_sj_vacature_url', $url);
            }

            $success = true;
        }
    }

    ob_start();

    if ($success): ?>

    <div class="sj-vp-notice sj-vp-notice--success">
        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true"><path d="M173.66,98.34a8,8,0,0,1,0,11.32l-56,56a8,8,0,0,1-11.32,0l-24-24a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35A8,8,0,0,1,173.66,98.34ZM232,128A104,104,0,1,1,128,24,104.11,104.11,0,0,1,232,128Zm-16,0a88,88,0,1,0-88,88A88.1,88.1,0,0,0,216,128Z"/></svg>
        <div>
            <strong>Aanvraag ontvangen!</strong>
            <p>We zetten je vacature zo snel mogelijk online. Je hoort van ons.</p>
        </div>
    </div>

    <?php else: ?>

    <?php if (!empty($errors)): ?>
    <div class="sj-vp-notice sj-vp-notice--error">
        <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true"><path d="M236.8,188.09,149.35,36.22a24.76,24.76,0,0,0-42.7,0L19.2,188.09a23.51,23.51,0,0,0,0,23.72A24.35,24.35,0,0,0,40.55,224h174.9a24.35,24.35,0,0,0,21.33-12.19A23.51,23.51,0,0,0,236.8,188.09ZM120,104a8,8,0,0,1,16,0v40a8,8,0,0,1-16,0Zm8,88a12,12,0,1,1,12-12A12,12,0,0,1,128,192Z"/></svg>
        <div>
            <strong>Er zijn een paar fouten:</strong>
            <ul>
                <?php foreach ($errors as $e): ?>
                    <li><?php echo esc_html($e); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
    <?php endif; ?>

    <div class="sj-vp">
        <div class="sj-vp__block">

            <header class="sj-vp__header">
                <h2 class="sj-vp__title">Snel plaatsen</h2>
                <p class="sj-vp__subtitle">Geef je e-mailadres en de link naar je vacature door. Wij zorgen op basis van alles wat we weten over jouw organisatie — logo, foto's en meer — dat de vacature er goed uitziet en online staat.</p>
            </header>

            <form method="post" class="sj-vp__form" novalidate>
                <?php wp_nonce_field('sj_snel_plaatsen', 'sj_sp_nonce'); ?>

                <div class="sj-vp__section">
                    <div class="sj-vp__grid sj-vp__grid--1">

                        <div class="sj-vp__field">
                            <label class="sj-vp__label" for="sp_email">E-mailadres <span class="sj-vp__req">*</span></label>
                            <input type="email" name="sp_email" id="sp_email" class="sj-vp__input"
                                   value="<?php echo esc_attr($_POST['sp_email'] ?? ''); ?>"
                                   placeholder="jan@bedrijf.nl" required>
                        </div>

                        <div class="sj-vp__field">
                            <label class="sj-vp__label" for="sp_url">Link naar de vacature <span class="sj-vp__req">*</span></label>
                            <input type="url" name="sp_url" id="sp_url" class="sj-vp__input"
                                   value="<?php echo esc_attr($_POST['sp_url'] ?? ''); ?>"
                                   placeholder="https://jouwbedrijf.nl/vacatures/functienaam" required>
                            <span class="sj-vp__hint">Wij halen zelf alle benodigde informatie op en zetten de vacature voor je online.</span>
                        </div>

                    </div>
                </div>

                <footer class="sj-vp__footer">
                    <button type="submit" class="sj-vp__submit">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 256 256" fill="currentColor" aria-hidden="true"><path d="M224,128a96,96,0,1,1-96-96A96.11,96.11,0,0,1,224,128Zm-16,0a80,80,0,1,0-80,80A80.09,80.09,0,0,0,208,128Zm-36.69-5.66-48-32A8,8,0,0,0,112,96v64a8,8,0,0,0,12.31,6.63l48-32a8,8,0,0,0,0-13.29Z"/></svg>
                        Vacature doorsturen
                    </button>
                    <p class="sj-vp__footer-note">Vragen? Mail naar <a href="mailto:support@sustainablejobs.nl">support@sustainablejobs.nl</a>.</p>
                </footer>

            </form>

        </div>
    </div>

    <?php endif;

    return ob_get_clean();
}
