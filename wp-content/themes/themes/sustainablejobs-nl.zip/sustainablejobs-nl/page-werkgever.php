<?php
/*
Template Name: SJ Werkgever Landing
*/

if (!defined('ABSPATH')) {
    exit;
}

get_header();
include get_stylesheet_directory() . '/template-parts/landing-werkgever.php';
get_footer();
