<?php
if ( ! defined( 'ABSPATH' ) ) exit;

wp_enqueue_script( 'wp-job-manager-ajax-filters' );
do_action( 'job_manager_job_filters_before', $atts );

$selected = [
  'job_company'      => [],
  'job_sector'       => [],
  'job_types'        => [],
  'organisatie_type' => [],
];

$shortcode_atts = shortcode_atts([
  'job_company'      => '',
  'job_sector'       => '',
  'job_listing_type' => '',
  'organisatie_type' => '',
], $atts);

if ( ! function_exists( 'sj_get_req_value' ) ) {
  function sj_get_req_value( $key ) {
    $filter_key = 'filter_' . $key;
    if ( ! empty( $_GET[ $key ] ) )         return (array) $_GET[ $key ];
    if ( ! empty( $_GET[ $filter_key ] ) )  return (array) $_GET[ $filter_key ];
    if ( ! empty( $_POST[ $filter_key ] ) ) return (array) $_POST[ $filter_key ];
    if ( ! empty( $_POST[ $key ] ) )        return (array) $_POST[ $key ];
    return [];
  }
}

foreach ( $selected as $key => &$value ) {
  $shortcode_key = ( $key === 'job_types' ) ? 'job_listing_type' : $key;
  $req = sj_get_req_value( $key );
  if ( ! empty( $req ) ) {
    $value = $req;
  } elseif ( ! empty( $shortcode_atts[ $shortcode_key ] ) ) {
    $value = array_filter( array_map( 'trim', explode( ',', sanitize_text_field( $shortcode_atts[ $shortcode_key ] ) ) ) );
  }
}
unset( $value );

$keywords = isset( $keywords ) ? $keywords : ( $_GET['search_keywords'] ?? '' );
$location = isset( $location ) ? $location : ( $_GET['search_location'] ?? '' );

if ( ! function_exists( 'sj_get_open_job_filter_counts' ) ) {
  function sj_get_open_job_filter_counts( $taxonomy ) {
    static $counts_by_taxonomy = [];
    $taxonomy = sanitize_key( $taxonomy );
    if ( isset( $counts_by_taxonomy[ $taxonomy ] ) ) return $counts_by_taxonomy[ $taxonomy ];
    if ( ! taxonomy_exists( $taxonomy ) ) {
      $counts_by_taxonomy[ $taxonomy ] = [];
      return $counts_by_taxonomy[ $taxonomy ];
    }
    global $wpdb;
    $sql = $wpdb->prepare(
      "SELECT tt.term_id, COUNT(DISTINCT p.ID) AS open_jobs
       FROM {$wpdb->term_relationships} tr
       INNER JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
       INNER JOIN {$wpdb->posts} p ON p.ID = tr.object_id
       LEFT JOIN {$wpdb->postmeta} filled  ON filled.post_id  = p.ID AND filled.meta_key  = '_filled'      AND filled.meta_value  = '1'
       LEFT JOIN {$wpdb->postmeta} expires ON expires.post_id = p.ID AND expires.meta_key = '_job_expires'
       WHERE tt.taxonomy = %s
         AND p.post_type   = 'job_listing'
         AND p.post_status = 'publish'
         AND filled.meta_id IS NULL
         AND (expires.meta_id IS NULL OR expires.meta_value = '' OR expires.meta_value >= %s)
       GROUP BY tt.term_id",
      $taxonomy,
      current_time( 'Y-m-d' )
    );
    $counts = [];
    foreach ( (array) $wpdb->get_results( $sql ) as $row ) {
      $counts[ (int) $row->term_id ] = (int) $row->open_jobs;
    }
    $counts_by_taxonomy[ $taxonomy ] = $counts;
    return $counts_by_taxonomy[ $taxonomy ];
  }
}

if ( ! function_exists( 'sj_render_filter_option_with_count' ) ) {
  function sj_render_filter_option_with_count( $term, $selected_values, $counts ) {
    $count           = $counts[ (int) $term->term_id ] ?? 0;
    $formatted_count = number_format_i18n( $count );
    ?>
    <option value="<?php echo esc_attr( $term->slug ); ?>"
      data-label="<?php echo esc_attr( $term->name ); ?>"
      data-count="<?php echo esc_attr( $formatted_count ); ?>"
      <?php selected( in_array( $term->slug, $selected_values, true ) ); ?>>
      <?php echo esc_html( $term->name . ' (' . $formatted_count . ')' ); ?>
    </option>
    <?php
  }
}

if ( ! function_exists( 'sj_sort_terms_by_open_job_count' ) ) {
  function sj_sort_terms_by_open_job_count( $terms, $counts ) {
    if ( empty( $terms ) || is_wp_error( $terms ) ) return [];
    $terms = array_values( (array) $terms );
    usort( $terms, function ( $a, $b ) use ( $counts ) {
      $count_a = $counts[ (int) $a->term_id ] ?? 0;
      $count_b = $counts[ (int) $b->term_id ] ?? 0;
      if ( $count_a === $count_b ) return strcasecmp( $a->name, $b->name );
      return $count_b <=> $count_a;
    } );
    return $terms;
  }
}

$job_type_counts         = sj_get_open_job_filter_counts( 'job_listing_type' );
$job_sector_counts       = sj_get_open_job_filter_counts( 'job_sector' );
$organisatie_type_counts = sj_get_open_job_filter_counts( 'organisatie_type' );
$job_company_counts      = sj_get_open_job_filter_counts( 'job_company' );
?>

<form class="job_filters">
  <?php do_action( 'job_manager_job_filters_start', $atts ); ?>

  <h2 class="filter-title">
    Vind jouw nieuwe baan in de
    <span class="filter-title-arrow" aria-hidden="true">→</span>
    <span class="filter-title-term" data-filter-title-terms="Duurzaamheid|Energietransitie|Ecologie|Biodiversiteit|Natuurbeheer|Dierenwelzijn|Voedseltransitie|Warmtetransitie|Klimaatadaptatie|Circulaire economie|Duurzame energie|Fondsenwerving|Ruimtelijke ordening|ESG">Duurzaamheid</span>
  </h2>
  <div class="filter-search-row">
    <?php do_action( 'job_manager_job_filters_search_jobs_start', $atts ); ?>

    <div class="filter-search-shell">
      <div class="search_keywords">
        <input type="text" name="search_keywords" id="search_keywords"
               placeholder="Functie of sector.."
               value="<?php echo esc_attr( $keywords ); ?>" />
      </div>

      <div class="search_location">
        <input type="text" name="search_location" id="search_location"
               placeholder="Stad of plaats"
               value="<?php echo esc_attr( $location ); ?>" />
      </div>

      <button type="submit" class="filter-submit">
        <span>Zoeken</span>
      </button>
    </div>

    <?php do_action( 'job_manager_job_filters_search_jobs_end', $atts ); ?>
  </div>

  <p class="filter-subtitle">Of maak een account aan als <a href="https://platform.sustainablejobs.nl/aanmelden/werkzoekende" target="_blank" rel="noopener">werkzoekende</a> of <a href="https://platform.sustainablejobs.nl/aanmelden/werkgever" target="_blank" rel="noopener">werkgever</a> op Sustainablejobs.nl.</p>

  <div class="filter-taxonomy-row">
    <!-- Dienstverband -->
    <div class="job_type">
      <select name="filter_job_types[]" id="filter_job_types"
              class="js-custom-select job_types"
              data-placeholder="Dienstverband"
              multiple>
        <?php foreach ( sj_sort_terms_by_open_job_count( get_job_listing_types(), $job_type_counts ) as $type ) : ?>
          <?php sj_render_filter_option_with_count( $type, $selected['job_types'], $job_type_counts ); ?>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- Sector -->
    <div class="job_sector">
      <select name="filter_job_sector[]" id="filter_job_sector"
              class="js-custom-select job_sector"
              data-placeholder="Sector"
              multiple>
        <?php foreach ( sj_sort_terms_by_open_job_count( get_terms( [ 'taxonomy' => 'job_sector', 'hide_empty' => true ] ), $job_sector_counts ) as $term ) : ?>
          <?php sj_render_filter_option_with_count( $term, $selected['job_sector'], $job_sector_counts ); ?>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- Type organisatie -->
    <div class="job_organisatie_type">
      <select name="filter_organisatie_type[]" id="filter_organisatie_type"
              class="js-custom-select job_organisatie_type"
              data-placeholder="Type organisatie"
              multiple>
        <?php foreach ( sj_sort_terms_by_open_job_count( get_terms( [ 'taxonomy' => 'organisatie_type', 'hide_empty' => false ] ), $organisatie_type_counts ) as $term ) : ?>
          <?php sj_render_filter_option_with_count( $term, $selected['organisatie_type'], $organisatie_type_counts ); ?>
        <?php endforeach; ?>
      </select>
    </div>

    <!-- Organisatie -->
    <div class="job_company">
      <select name="filter_job_company[]" id="filter_job_company"
              class="js-custom-select job_company"
              data-placeholder="Organisatie"
              multiple>
        <?php foreach ( sj_sort_terms_by_open_job_count( get_terms( [ 'taxonomy' => 'job_company', 'hide_empty' => true ] ), $job_company_counts ) as $term ) : ?>
          <?php sj_render_filter_option_with_count( $term, $selected['job_company'], $job_company_counts ); ?>
        <?php endforeach; ?>
      </select>
    </div>
  </div>

  <!-- Actieve filters -->
  <div class="active-filters" id="active-filters" aria-live="polite"></div>

</form>

<?php do_action( 'job_manager_job_filters_after', $atts ); ?>

<script>
if ('scrollRestoration' in history) {
  history.scrollRestoration = 'manual';
}
window.addEventListener('pageshow', function(e) {
  if (e.persisted) window.scrollTo(0, 0);
});

document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form.job_filters");
  if (!form) return;

  const rotatingTitleTerm = document.querySelector("[data-filter-title-terms]");
  if (rotatingTitleTerm) {
    const terms = rotatingTitleTerm.dataset.filterTitleTerms.split("|").filter(Boolean);
    let termIndex = 0;

    window.setInterval(() => {
      termIndex = (termIndex + 1) % terms.length;
      rotatingTitleTerm.classList.add("is-changing");

      window.setTimeout(() => {
        rotatingTitleTerm.textContent = terms[termIndex];
        rotatingTitleTerm.classList.remove("is-changing");
      }, 180);
    }, 2600);
  }

  const wpjmFilter = () => {
    const listings = form.closest("div.job_listings");
    if (!listings || !window.jQuery) return;

    window.jQuery(listings).triggerHandler("update_results", [1, false]);
  };

  const debounce = (fn, delay = 250) => {
    let t;
    return () => { clearTimeout(t); t = setTimeout(fn, delay); };
  };

  const kw  = document.querySelector("#search_keywords");
  const loc = document.querySelector("#search_location");
  if (kw)  kw.addEventListener("input",  debounce(wpjmFilter, 250));
  if (loc) loc.addEventListener("input", debounce(wpjmFilter, 250));

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    wpjmFilter();
  });

  const closeAll = () => {
    document.querySelectorAll(".sj-select.active").forEach((el) => {
      el.classList.remove("active");
      const searchInput = el.querySelector(".sj-search-input");
      if (searchInput) {
        searchInput.value = "";
        el.querySelectorAll(".sj-option").forEach((option) => {
          option.style.display = "";
        });
      }
    });
  };

  const activeFiltersEl = document.getElementById("active-filters");

  const renderActiveFilters = () => {
    if (!activeFiltersEl) return;
    activeFiltersEl.innerHTML = "";

    document.querySelectorAll("select.js-custom-select").forEach((select) => {
      const selectedOptions = [...select.options].filter(o => o.selected && o.value !== "");
      selectedOptions.forEach((opt) => {
        const chip = document.createElement("span");
        chip.className = "active-filter";
        chip.setAttribute("role", "button");
        chip.setAttribute("title", "Verwijder filter");
        chip.innerHTML = `<span class="active-filter-text"></span><span class="active-filter-x" aria-hidden="true">×</span>`;
        chip.querySelector(".active-filter-text").textContent = opt.dataset.label || opt.textContent;
        chip.addEventListener("click", (e) => {
          e.preventDefault();
          opt.selected = false;
          select.dispatchEvent(new Event("change", { bubbles: true }));
        });
        activeFiltersEl.appendChild(chip);
      });
    });

    const hasActiveFilters = activeFiltersEl.children.length > 0;
    activeFiltersEl.style.display = hasActiveFilters ? "flex" : "none";
    form.classList.toggle("has-active-filters", hasActiveFilters);
  };

  const buildSelect = (select) => {
    const isMultiple  = select.multiple === true;
    const forceMode   = select.dataset.mode;
    const isSingle    = forceMode === "single" ? true : !isMultiple;
    const placeholder = select.dataset.placeholder || "Selecteer";

    const wrap = document.createElement("div");
    wrap.className = "sj-select-wrap";
    select.parentNode.insertBefore(wrap, select);
    wrap.appendChild(select);
    select.classList.add("sj-hidden-select");

    const root = document.createElement("div");
    root.className = "sj-select";
    root.dataset.type = isSingle ? "single" : "multi";

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "sj-select-btn";
    btn.innerHTML = `
      <span class="sj-btn-content">
        <span class="sj-placeholder">${placeholder}</span>
        <span class="sj-tags" aria-hidden="true"></span>
      </span>
      <span class="sj-actions">
        <button type="button" class="sj-clear" aria-label="Wis selectie" title="Wis selectie">×</button>
        <span class="sj-chev" aria-hidden="true"></span>
      </span>
    `;

    const clearBtn = btn.querySelector(".sj-clear");
    clearBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      [...select.options].forEach(o => o.selected = false);
      renderState();
      select.dispatchEvent(new Event("change", { bubbles: true }));
    });

    const list = document.createElement("div");
    list.className = "sj-options";
    list.setAttribute("role", "listbox");
    if (!isSingle) list.setAttribute("aria-multiselectable", "true");

    let searchInput = null;
    if (!isSingle) {
      const searchWrap = document.createElement("div");
      searchWrap.className = "sj-search";
      searchWrap.innerHTML = `<input type="text" class="sj-search-input" placeholder="Zoek in ${placeholder.toLowerCase()}">`;
      searchInput = searchWrap.querySelector(".sj-search-input");
      list.appendChild(searchWrap);
    }

    const makeOptionRow = (opt) => {
      const row = document.createElement("div");
      row.className = "sj-option";
      row.dataset.value = opt.value;
      row.setAttribute("role", "option");
      row.setAttribute("aria-selected", opt.selected ? "true" : "false");
      const optionLabel = opt.dataset.label || opt.textContent.trim();
      const optionCount = opt.dataset.count;
      row.innerHTML = `<span class="sj-option-text"></span>${optionCount !== undefined ? '<span class="sj-option-count"></span>' : ''}`;
      row.querySelector(".sj-option-text").textContent = optionLabel;
      const countEl = row.querySelector(".sj-option-count");
      if (countEl) countEl.textContent = optionCount;

      const syncSelected = () => {
        row.classList.toggle("is-selected", opt.selected);
        row.setAttribute("aria-selected", opt.selected ? "true" : "false");
      };
      syncSelected();

      row.addEventListener("click", (e) => {
        e.preventDefault();
        if (opt.disabled) return;
        if (isSingle) {
          [...select.options].forEach(o => o.selected = false);
          opt.selected = true;
          closeAll();
          root.classList.remove("active");
        } else {
          opt.selected = !opt.selected;
        }
        renderState();
        select.dispatchEvent(new Event("change", { bubbles: true }));
      });

      return { row, syncSelected };
    };

    const optionRows = [];
    [...select.options].forEach((opt) => {
      if (isSingle && opt.value === "") return;
      const { row, syncSelected } = makeOptionRow(opt);
      optionRows.push({ opt, row, syncSelected });
      list.appendChild(row);
    });

    const filterOptionRows = () => {
      if (!searchInput) return;
      const term = searchInput.value.trim().toLowerCase();
      optionRows.forEach(({ row, opt }) => {
        const optionLabel = opt.dataset.label || opt.textContent;
        row.style.display = optionLabel.toLowerCase().includes(term) ? "" : "none";
      });
    };

    if (searchInput) {
      searchInput.addEventListener("input", filterOptionRows);
      searchInput.addEventListener("click", (e) => e.stopPropagation());
      searchInput.addEventListener("keydown", (e) => e.stopPropagation());
    }

    const tagsEl        = btn.querySelector(".sj-tags");
    const placeholderEl = btn.querySelector(".sj-placeholder");

    const renderState = () => {
      optionRows.forEach(({ syncSelected }) => syncSelected());
      const selectedOptions = [...select.options].filter(o => o.selected && o.value !== "");
      tagsEl.innerHTML = "";

      if (selectedOptions.length === 0) {
        placeholderEl.style.display = "inline";
        tagsEl.style.display = "none";
        clearBtn.style.display = "none";
        return;
      }

      clearBtn.style.display = "inline-flex";
      placeholderEl.textContent = placeholder;
      placeholderEl.style.display = "inline";
      tagsEl.style.display = "none";
    };

    renderState();

    btn.addEventListener("click", (e) => {
      if (e.target.closest(".sj-clear")) return;
      e.preventDefault();
      const wasOpen = root.classList.contains("active");
      closeAll();
      if (!wasOpen) {
        root.classList.add("active");
        if (searchInput) {
          searchInput.value = "";
          filterOptionRows();
          window.setTimeout(() => searchInput.focus(), 10);
        }
      }
    });

    select.addEventListener("change", () => {
      renderState();
      renderActiveFilters();
      wpjmFilter();
    });

    root.appendChild(btn);
    root.appendChild(list);
    wrap.appendChild(root);
  };

  document.querySelectorAll("select.js-custom-select").forEach(buildSelect);
  renderActiveFilters();

  document.addEventListener("click", (e) => {
    if (!e.target.closest(".sj-select")) closeAll();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAll();
  });
});

jQuery(function($) {
  const updateHeroJobCount = (count) => {
    const parsed = parseInt(String(count).replace(/[^\d]/g, ""), 10);
    if (Number.isNaN(parsed)) return;

    $(".sj-hero-job-count").text(new Intl.NumberFormat(document.documentElement.lang || "nl-NL").format(parsed));
  };

  $("div.job_listings").on("updated_results", function(event, result) {
    if (result && typeof result.found_count !== "undefined") {
      updateHeroJobCount(result.found_count);
    } else if (result && result.found_jobs === false) {
      updateHeroJobCount(0);
    }
  });
});

// Scroll fix voor taxonomy-pagina's
(function () {
  var parts = window.location.pathname.replace(/\/+$/, "").split("/").filter(Boolean);
  if (parts.length < 2) return;

  var corrected  = false;
  var listingsEl = document.querySelector(".job_listings");
  if (!listingsEl) return;

  var scrollToFilter = function () {
    if (corrected) return;
    corrected = true;
    observer.disconnect();
    requestAnimationFrame(function () {
      var filter = document.querySelector("form.job_filters");
      if (!filter) return;
      var filterTop = filter.getBoundingClientRect().top + window.scrollY;
      window.scrollTo({ top: Math.max(0, filterTop - 100), behavior: "smooth" });
    });
  };

  var observer = new MutationObserver(scrollToFilter);
  observer.observe(listingsEl, { childList: true, subtree: true, attributes: true, attributeFilter: ["class"] });

  window.addEventListener("load", function () {
    setTimeout(scrollToFilter, 1000);
  });
}());
</script>

<style>
/* ── Filter bar ── */
.job_filters {
  width: 100vw;
  position: relative;
  left: 50%;
  right: 50%;
  margin-left: -50vw;
  margin-right: -50vw;
  margin-top: 0;
  margin-bottom: 40px !important;
  height: auto !important;
  min-height: 400px;
  background: transparent;
  border-bottom: 0;
  display: flex;
  flex-direction: column;
  justify-content: center;
  overflow: visible;
  box-sizing: border-box;
  scroll-margin-top: 90px;
}

.job_filters.has-active-filters {
  min-height: 400px;
  padding: 28px 0 34px;
  justify-content: center;
}

.filter-title,
.filter-subtitle,
.filter-search-row,
.filter-taxonomy-row,
.active-filters {
  width: 100%;
  max-width: 1200px;
  margin-left: auto !important;
  margin-right: auto !important;
  box-sizing: border-box;
}

.filter-title {
  padding: 0 24px;
  margin-top: 0 !important;
  margin-bottom: 0 !important;
  font-family: "Work Sans", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif !important;
  font-size: 32px !important;
  font-weight: 800 !important;
  line-height: 1.12 !important;
  letter-spacing: 0 !important;
  text-align: center;
  color: #333333 !important;
}

.filter-title-term {
  display: inline-block;
  min-width: 9.8em;
  text-align: left;
  color: var(--color-primary);
  transition: opacity .18s ease, transform .18s ease;
}

.filter-title-arrow {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 1.6em;
  color: var(--color-primary);
  transform: translateY(-0.03em);
}

.filter-title-term.is-changing {
  opacity: 0;
  transform: translateY(4px);
}

.filter-subtitle {
  padding: 0 24px;
  margin-top: 18px !important;
  margin-bottom: 0 !important;
  font-family: 'Poppins', sans-serif !important;
  font-size: 15px !important;
  font-weight: 400 !important;
  line-height: 1.45 !important;
  letter-spacing: 0 !important;
  text-align: center;
  color: #333333 !important;
}

.filter-subtitle a {
  color: var(--color-primary) !important;
  font-weight: 600 !important;
  text-decoration: none !important;
}

.filter-subtitle a:hover,
.filter-subtitle a:focus {
  color: var(--color-primary-hover) !important;
}

.filter-search-row {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 30px 24px 0;
}

.filter-search-shell {
  width: min(100%, 760px);
  min-height: 44px;
  display: grid;
  grid-template-columns: minmax(220px, 1fr) minmax(180px, 0.8fr) 140px;
  align-items: stretch;
  overflow: hidden;
  background: #ffffff;
  border: 1px solid #D3DDDA;
  border-radius: 8px;
  box-shadow: 0 18px 40px -30px rgba(37, 79, 110, 0.5);
}

.job_filters .search_keywords,
.job_filters .search_location {
  flex: 1;
  display: flex;
  align-items: center;
  position: relative;
  min-width: 0;
}

.job_filters .search_keywords,
.job_filters .search_location {
  border-right: 1px solid #D3DDDA;
}

.filter-search-shell input[type="text"] {
  width: 100%;
  height: 44px;
  padding: 0 14px 0 40px;
  font-size: 15px;
  border: 0;
  border-radius: 0;
  background-color: #ffffff;
  color: var(--color-text);
  transition: border-color .2s ease, box-shadow .2s ease;
  font-family: 'Poppins', sans-serif;
  font-weight: 400;
  box-sizing: border-box;
}

.filter-search-shell input[type="text"]:focus {
  outline: none;
  box-shadow: inset 0 0 0 2px rgba(44, 143, 175, 0.18);
}

.job_filters .search_keywords input::placeholder,
.job_filters .search_location input::placeholder {
  color: #7c7c7c;
  font-size: 15px !important;
  font-style: italic;
  font-weight: 400;
}

.job_filters .search_keywords::before,
.job_filters .search_location::before {
  content: '';
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  width: 17px;
  height: 17px;
  background-repeat: no-repeat;
  background-size: contain;
  pointer-events: none;
}

.job_filters .search_keywords::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23168AAD' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cpath d='m21 21-4.35-4.35'/%3E%3C/svg%3E");
}

.job_filters .search_location::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23168AAD' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 2a7 7 0 0 1 7 7c0 5.25-7 13-7 13S5 14.25 5 9a7 7 0 0 1 7-7z'/%3E%3Ccircle cx='12' cy='9' r='2.5'/%3E%3C/svg%3E");
}

.filter-submit {
  min-height: 44px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 0 18px;
  border: 0;
  border-radius: 0;
  background: var(--color-primary-dk);
  color: #ffffff;
  cursor: pointer;
  font-family: 'Poppins', sans-serif;
  font-size: 15px;
  font-weight: 800;
  line-height: 1;
  transition: background-color .18s ease, box-shadow .18s ease;
}

.filter-submit::before {
  content: '';
  width: 17px;
  height: 17px;
  flex: 0 0 auto;
  background-repeat: no-repeat;
  background-size: contain;
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23ffffff' stroke-width='2.3' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cpath d='m21 21-4.35-4.35'/%3E%3C/svg%3E");
}

.filter-submit:hover,
.filter-submit:focus {
  outline: none;
  background: var(--color-primary-hover);
  box-shadow: inset 0 0 0 2px rgba(255, 255, 255, 0.18);
}

.filter-taxonomy-row {
  display: flex;
  justify-content: center;
  align-items: center;
  flex-wrap: wrap;
  gap: 12px;
  padding: 26px 24px 0;
}

.filter-taxonomy-row > div {
  flex: 0 0 auto;
  min-width: 0;
}

/* ── Custom select ── */
select.sj-hidden-select {
  position: absolute !important;
  left: -9999px !important;
  width: 1px !important;
  height: 1px !important;
  opacity: 0 !important;
}

.sj-select-wrap,
.sj-select {
  position: relative;
  width: auto;
  display: inline-block;
}

.sj-select-btn {
  width: auto;
  display: inline-flex;
  align-items: center;
  justify-content: space-between;
  white-space: nowrap;
  border-radius: 999px;
  border: 1px solid #DDE8C5 !important;
  background-color: #ffffff !important;
  padding: 12px;
  min-height: 44px;
  cursor: pointer;
  user-select: none;
  font-family: 'Poppins', sans-serif;
  font-weight: 700;
  font-size: 15px;
  color: #111111 !important;
}

.sj-select-btn:focus,
.sj-select.active .sj-select-btn {
  outline: none;
  border-color: var(--color-primary) !important;
  box-shadow: 0 0 0 2px rgba(22, 138, 173, 0.18);
  background: #ffffff !important;
  color: #111111 !important;
}

.sj-btn-content {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  min-width: 0;
}

.sj-placeholder {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-family: 'Poppins', sans-serif;
  font-weight: 700;
  color: var(--color-text);
  font-size: 14px;
}

.sj-tags {
  display: none;
  gap: 6px;
  align-items: center;
  flex-wrap: wrap;
}

.sj-actions {
  display: inline-flex;
  align-items: center;
  gap: 0 !important;
  margin-left: 10px;
}

.sj-clear {
  display: none !important;
}

.sj-chev {
  width: 9px;
  height: 9px;
  border-right: 2px solid #111;
  border-bottom: 2px solid #111;
  transform: rotate(45deg);
  transition: transform .2s ease;
}

.sj-select.active .sj-chev {
  transform: rotate(-135deg);
}

.sj-options {
  display: none;
  position: absolute;
  left: 0;
  right: auto;
  width: max-content;
  min-width: 100%;
  margin-top: 10px;
  background: #fff;
  border: 1px solid #DDE8C5;
  border-radius: 8px;
  box-shadow: 0 10px 40px -5px rgba(0, 0, 0, 0.12);
  padding: 8px;
  max-height: 280px;
  overflow: auto;
  z-index: 9999;
}

.sj-select.active .sj-options {
  display: block;
}

.sj-search {
  position: sticky;
  top: 0;
  z-index: 2;
  background: #ffffff;
  padding: 4px 4px 10px;
}

.sj-search-input {
  width: 100%;
  min-width: 220px;
  border: 1px solid #DDE8C5;
  border-radius: 8px;
  padding: 11px 12px;
  font-family: 'Poppins', sans-serif;
  font-size: 13px;
  color: var(--color-text);
  background: #ffffff;
  box-sizing: border-box;
}

.sj-search-input::placeholder { color: #7c7c7c; }

.sj-search-input:focus {
  outline: none;
  border-color: var(--color-primary);
  box-shadow: 0 0 0 2px rgba(22, 138, 173, 0.16);
}

.sj-option {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 10px;
  min-width: 240px;
  padding: 10px 12px;
  border-radius: 8px;
  cursor: pointer;
}

.sj-option:hover { background: var(--color-bg-filter); }

.sj-option.is-selected .sj-option-text {
  color: var(--color-primary);
  font-weight: 700;
}

.sj-option-text {
  min-width: 0;
  overflow-wrap: anywhere;
  font-family: 'Poppins', sans-serif;
  font-size: 15px;
  font-weight: 600;
  color: var(--color-text);
}

.sj-option-count {
  flex: 0 0 auto;
  margin-left: 16px;
  font-family: 'Poppins', sans-serif;
  font-size: 13px;
  font-weight: 700;
  color: var(--color-text-muted);
}

.sj-option.is-selected .sj-option-count { color: var(--color-primary); }

/* Filter knop iconen */
.job_type .sj-select-btn,
.job_sector .sj-select-btn,
.job_organisatie_type .sj-select-btn,
.job_company .sj-select-btn {
  padding-left: 38px !important;
  position: relative;
}

.job_type .sj-select-btn::before,
.job_sector .sj-select-btn::before,
.job_organisatie_type .sj-select-btn::before,
.job_company .sj-select-btn::before {
  content: '';
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  width: 15px;
  height: 15px;
  background-repeat: no-repeat;
  background-size: contain;
  pointer-events: none;
  flex-shrink: 0;
}

.job_type .sj-select-btn::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23168AAD' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='2' y='7' width='20' height='14' rx='2'/%3E%3Cpath d='M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2'/%3E%3Cline x1='12' y1='12' x2='12' y2='17'/%3E%3Cline x1='9.5' y1='14.5' x2='14.5' y2='14.5'/%3E%3C/svg%3E");
}

.job_sector .sj-select-btn::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23168AAD' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='3' width='7' height='7'/%3E%3Crect x='14' y='3' width='7' height='7'/%3E%3Crect x='3' y='14' width='7' height='7'/%3E%3Crect x='14' y='14' width='7' height='7'/%3E%3C/svg%3E");
}

.job_organisatie_type .sj-select-btn::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23168AAD' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='12' cy='8' r='6'/%3E%3Cpath d='M15.477 12.89L17 22l-5-3-5 3 1.523-9.11'/%3E%3C/svg%3E");
}

.job_company .sj-select-btn::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%23168AAD' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/%3E%3Cpolyline points='9 22 9 12 15 12 15 22'/%3E%3C/svg%3E");
}

/* Actieve filters */
.active-filters {
  display: none;
  flex-wrap: wrap;
  justify-content: center;
  gap: 10px;
  padding: 18px 24px 0;
}

.job_filters.has-active-filters .active-filters {
  padding-bottom: 0;
}

span.active-filter {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #ffffff;
  border: 1px solid var(--color-chip-company-text);
  border-radius: 999px;
  box-shadow: 0 10px 24px -18px rgba(37, 79, 110, 0.38);
  padding: 8px 12px;
  font-size: 14px;
  color: var(--color-chip-company-text);
  font-weight: 700;
  cursor: pointer;
  transition: background-color .18s ease, border-color .18s ease, transform .18s ease;
}

.active-filter:hover {
  background: var(--color-secondary-soft);
  transform: translateY(-1px);
}

.active-filter-text { color: inherit; font-weight: 700; }

.active-filter-x {
  color: var(--color-chip-company-text);
  font-weight: 700;
  font-size: 18px;
  line-height: 1;
  margin-left: 4px;
  pointer-events: none;
}

/* Responsive */
@media (max-width: 960px) {
  form.job_filters {
    width: 100% !important;
    position: relative !important;
    left: 0 !important;
    right: auto !important;
    margin: 0 0 40px !important;
    min-height: 0 !important;
  }

  .filter-title {
    padding: 0 16px !important;
    margin-top: 24px !important;
    font-size: 32px !important;
  }

  .filter-subtitle {
    padding: 0 16px !important;
    font-size: 15px !important;
  }

  .filter-search-row {
    padding: 24px 16px 0 !important;
  }

  .filter-search-shell {
    width: 100%;
    display: flex;
    flex-direction: column;
    min-height: 0;
    overflow: hidden;
  }

  .job_filters .search_keywords,
  .job_filters .search_location {
    flex: none;
    width: 100%;
    border-right: 0;
    border-bottom: 1px solid #D3DDDA;
  }

  .filter-search-shell input[type="text"] {
    height: 44px;
    font-size: 15px;
    padding-left: 40px;
  }

  .job_filters .search_keywords input::placeholder,
  .job_filters .search_location input::placeholder {
    font-size: 15px !important;
  }

  .job_filters .search_keywords::before,
  .job_filters .search_location::before {
    left: 12px;
    width: 17px;
    height: 17px;
  }

  .filter-submit {
    width: 100%;
    min-height: 44px;
    font-size: 15px;
  }

  .filter-taxonomy-row {
    flex-direction: column;
    align-items: stretch;
    gap: 10px;
    padding: 20px 16px 0 !important;
    width: 100%;
    box-sizing: border-box;
  }

  .filter-taxonomy-row > div,
  .sj-select-wrap,
  .sj-select,
  .sj-select-btn {
    width: 100% !important;
    max-width: 100% !important;
    box-sizing: border-box;
  }

  .sj-select-btn {
    min-width: 0;
    white-space: normal;
  }

  .sj-btn-content {
    flex: 1 1 auto;
  }

  .sj-placeholder {
    white-space: normal;
  }

  .sj-options {
    width: 100% !important;
    min-width: 0 !important;
    left: 0 !important;
    right: 0 !important;
  }

  .active-filters {
    padding: 0 16px 16px !important;
    box-sizing: border-box;
  }

  span.active-filter {
    max-width: 100%;
    box-sizing: border-box;
  }

  .active-filter-text {
    min-width: 0;
    overflow-wrap: anywhere;
  }
}
</style>
