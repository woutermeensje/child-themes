<?php
if ( ! defined( 'ABSPATH' ) ) exit;

global $post;

if ( job_manager_user_can_view_job_listing( $post->ID ) ) : ?>

<div class="sj-wrap">

    <div class="sj-card">
      <?php if ( get_option( 'job_manager_hide_expired_content', 1 ) && 'expired' === $post->post_status ) : ?>
        <div class="job-manager-info"><?php _e( 'This listing has expired.', 'wp-job-manager' ); ?></div>
      <?php else : ?>

        <?php
        $company_name    = function_exists('get_the_company_name') ? get_the_company_name() : '';
        $company_website = get_post_meta( $post->ID, '_company_website', true );
        ?>

        <div class="sj-meta">
          <span class="sj-chip">🗓️ <?php echo esc_html( date_i18n( 'j F Y', get_post_time( 'U' ) ) ); ?></span>
          <span class="sj-chip">🏷️ <?php the_job_type(); ?></span>

          <?php if ( ! empty( $company_name ) ) : ?>
            <span class="sj-chip">🏢 <?php echo esc_html( $company_name ); ?></span>
          <?php endif; ?>
        </div>

        <header class="sj-header">
          <h1 class="sj-title"><?php wpjm_the_job_title(); ?></h1>
          <?php if ( ! empty( $company_name ) ) : ?>
            <p class="sj-subtitle"><?php echo esc_html( $company_name ); ?></p>
          <?php endif; ?>
        </header>

        <div class="job_description sj-content">
          <?php wpjm_the_job_description(); ?>
        </div>

        <?php if ( ! empty( $company_website ) ) : ?>
          <div class="sj-actions">
            <a href="<?php echo esc_url( $company_website ); ?>" class="sj-btn" target="_blank" rel="noopener">
              Solliciteer op deze vacature
            </a>
          </div>
        <?php endif; ?>

        <?php do_action( 'single_job_listing_end' ); ?>

      <?php endif; ?>
    </div>

    <?php
    $cf = get_post_meta( get_the_ID(), '_contact_first_name', true );
    $cl = get_post_meta( get_the_ID(), '_contact_last_name', true );
    $ce = get_post_meta( get_the_ID(), '_contact_email', true );
    $has_contact = ( ! empty($cf) || ! empty($cl) || ! empty($ce) );
    ?>

    <?php if ( $has_contact ) : ?>
      <section class="sj-contact sj-card">
        <h2 class="sj-contact-title">Contactpersoon Vacature</h2>
        <div class="sj-contact-grid">
          <?php if ( ! empty($cf) || ! empty($cl) ) : ?>
            <div class="sj-contact-row">
              <span class="sj-contact-label">Contactpersoon</span>
              <span class="sj-contact-value"><?php echo esc_html( trim($cf . ' ' . $cl) ); ?></span>
            </div>
          <?php endif; ?>
          <?php if ( ! empty($ce) ) : ?>
            <div class="sj-contact-row">
              <span class="sj-contact-label">E-mail</span>
              <a class="sj-contact-value sj-contact-link" href="mailto:<?php echo esc_attr( antispambot($ce) ); ?>">
                <?php echo esc_html( antispambot($ce) ); ?>
              </a>
            </div>
          <?php endif; ?>
        </div>
      </section>
    <?php endif; ?>

  </div>

<?php else : ?>
  <?php get_job_manager_template_part( 'access-denied', 'single-job_listing' ); ?>
<?php endif; ?>

<style>
:root {
  --sj-ink: #111827;
  --sj-muted: #6B7280;
  --sj-border: #E5E7EB;
  --sj-card: #FFFFFF;
  --sj-blue: var(--color-primary);
  --sj-radius: 12px;
}

.sj-wrap{ max-width:900px; width:100%; margin:56px auto; padding:0 16px; display:grid; gap:16px; }
.job_description,.sj-content{ overflow-wrap:anywhere; word-break:break-word; }

.sj-card{ padding:24px; background:#ffffff; border:1px solid #DEDEDE; border-radius:5px; }

.single_job_listing{ padding:22px; }
.job-manager-info{ padding:14px 16px; border:1px solid var(--sj-border); border-radius:10px; background:#fff; font-family:Poppins,system-ui,sans-serif; color:var(--sj-ink); }

.sj-meta{ display:flex; flex-wrap:wrap; gap:10px; margin-bottom:14px; }
.sj-chip{ display:inline-flex; align-items:center; gap:8px; padding:8px 10px; border-radius:999px; border:1px solid #DEDEDE; background:#fff; color:#333; font-family:Poppins,system-ui,sans-serif; font-weight:700; font-size:14px; }
.sj-chip--link{ text-decoration:none; }
.sj-chip--link:hover{ border-color:rgba(37,71,107,.35); }

.sj-header{ padding-bottom:14px; border-bottom:1px solid var(--sj-border); margin-bottom:16px; margin-top:24px; }
.sj-title{ margin:0; font-family:Inter,system-ui,sans-serif; font-size:26px; line-height:1.15; font-weight:800; color:var(--sj-ink); max-width:100%; white-space:normal; overflow-wrap:anywhere; word-break:break-word; hyphens:auto; }
.sj-subtitle{ margin:8px 0 0 0; font-family:Poppins,system-ui,sans-serif; font-size:14px; font-weight:600; color:var(--sj-blue); }

.sj-content{ font-family:Poppins,system-ui,sans-serif; color:var(--sj-ink); font-size:15px; line-height:1.75; }
.sj-content p{ margin:0 0 14px 0; }

.sj-actions{ margin-top:18px; display:flex; }
.sj-btn{ display:inline-flex; align-items:center; justify-content:center; padding:10px 14px; border-radius:10px; background:rgba(37,71,107,0.12); color:var(--color-primary); text-decoration:none; border:1px solid var(--color-primary); font-family:Poppins,system-ui,sans-serif; font-weight:700; font-size:14px; transition:transform .15s ease,filter .15s ease; }
.sj-btn:hover{ transform:translateY(-1px); }

.single-job_listing h1.entry-title{ display:none; }

.sj-contact{ padding:24px; }
h2.sj-contact-title{ font-family:Poppins; font-weight:600; font-size:20px; color:#333; }
.sj-contact-grid{ display:grid; grid-template-columns:1fr 1fr; gap:28px 56px; }
.sj-contact-row{ display:grid; gap:8px; }
.sj-contact-label{ font-family:Poppins,system-ui,sans-serif; font-size:16px; font-weight:600; color:#7A7F87; }
.sj-contact-value{ font-family:Poppins,system-ui,sans-serif; font-size:14px; font-weight:400; color:#333; line-height:1.25; word-break:break-word; }
.sj-contact-link{ color:var(--color-primary); text-decoration:none; }
.sj-contact-link:hover{ text-decoration:underline; }

@media (max-width:768px){
  *, *::before, *::after{ box-sizing:border-box; }
  .sj-wrap,.single_job_listing,.sj-contact,.sj-card{ width:100%; max-width:100%; box-sizing:border-box; }
  .sj-wrap{ padding:0 16px; }
  .sj-meta,.sj-contact-grid{ min-width:0; }
  .sj-contact-grid{ grid-template-columns:1fr; gap:18px; }
  img{ max-width:100%; height:auto; }
}
</style>
