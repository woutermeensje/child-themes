<?php
if (!defined('ABSPATH')) exit;

wp_enqueue_script('wp-job-manager-ajax-filters');
do_action('job_manager_job_filters_before', $atts);

// Vul $selected met waarden vanuit: $_GET > $_POST > Shortcode
$selected = [
    'job_company' => [],
    'job_sector'  => [],
    'job_regio'   => [],
    'job_name'    => [],
    'job_types'   => [],
];

$shortcode_atts = shortcode_atts([
    'job_company'      => '',
    'job_sector'       => '',
    'job_regio'        => '',
    'job_name'         => '',
    'job_listing_type' => '',
], $atts);

foreach ($selected as $key => &$value) {
    $shortcode_key = $key === 'job_types' ? 'job_listing_type' : $key;

    $req = srmb_get_req_value($key);
    if (!empty($req)) {
        $value = $req;
    } elseif (!empty($shortcode_atts[$shortcode_key])) {
        $value = array_filter(array_map('trim', explode(',', sanitize_text_field($shortcode_atts[$shortcode_key]))));
    }
}
unset($value);
?>

<form class="job_filters dr-job-filters">
    <?php do_action('job_manager_job_filters_start', $atts); ?>

    <div class="filter-header">
        <h2 class="dr-filters__title">Bekijk alle vacatures en opdrachten!</h2>
        <p class="dr-filters__intro">Of stel een <a href="https://dereceptionist.nl/inschrijven/" target="_blank" class="dr-filters__alert-link">vacature alert in!</a></p>
    </div>

    <div class="search-basic">
        <?php do_action('job_manager_job_filters_search_jobs_start', $atts); ?>

        <div class="search_keywords">
            <input type="text" class="dr-filters__input" name="search_keywords" id="search_keywords" placeholder="Functienaam, sector of onderwerp.." value="<?php echo esc_attr($keywords); ?>" />
        </div>

        <div class="search_location">
            <input type="text" class="dr-filters__input" name="search_location" id="search_location" placeholder="Stad of plaats" value="<?php echo esc_attr($location); ?>" />
        </div>

        <?php do_action('job_manager_job_filters_search_jobs_end', $atts); ?>
    </div>

    <div class="filter-box">

        <!-- Dienstverband -->
        <div class="job_type">
            <select name="filter_job_types[]"
                    id="filter_job_types"
                    class="js-custom-select job_types"
                    data-placeholder="Dienstverband"
                    multiple>
                <?php foreach (get_job_listing_types() as $type) : ?>
                    <option value="<?php echo esc_attr($type->slug); ?>" <?php selected(in_array($type->slug, $selected['job_types'], true)); ?>>
                        <?php echo esc_html($type->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Sector -->
        <div class="job_sector">
            <select name="filter_job_sector[]"
                    id="filter_job_sector"
                    class="js-custom-select job_sector"
                    data-placeholder="Sector"
                    multiple>
                <?php foreach (get_terms(['taxonomy' => 'job_sector', 'hide_empty' => true]) as $term) : ?>
                    <option value="<?php echo esc_attr($term->slug); ?>" <?php selected(in_array($term->slug, $selected['job_sector'], true)); ?>>
                        <?php echo esc_html($term->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Regio -->
        <div class="job_regio">
            <select name="filter_job_regio[]"
                    id="filter_job_regio"
                    class="js-custom-select job_regio"
                    data-placeholder="Regio"
                    multiple>
                <?php foreach (get_terms(['taxonomy' => 'job_regio', 'hide_empty' => true]) as $term) : ?>
                    <option value="<?php echo esc_attr($term->slug); ?>" <?php selected(in_array($term->slug, $selected['job_regio'], true)); ?>>
                        <?php echo esc_html($term->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Beroep / Job Name -->
        <div class="job_name">
            <select name="filter_job_name[]"
                    id="filter_job_name"
                    class="js-custom-select job_name"
                    data-placeholder="Beroep"
                    multiple>
                <?php foreach (get_terms(['taxonomy' => 'job_name', 'hide_empty' => true]) as $term) : ?>
                    <option value="<?php echo esc_attr($term->slug); ?>" <?php selected(in_array($term->slug, $selected['job_name'], true)); ?>>
                        <?php echo esc_html($term->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Organisatie -->
        <div class="job_company">
            <select name="filter_job_company[]"
                    id="filter_job_company"
                    class="js-custom-select job_company"
                    data-placeholder="Organisatie"
                    multiple>
                <?php foreach (get_terms(['taxonomy' => 'job_company', 'hide_empty' => true]) as $term) : ?>
                    <option value="<?php echo esc_attr($term->slug); ?>" <?php selected(in_array($term->slug, $selected['job_company'], true)); ?>>
                        <?php echo esc_html($term->name); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

    </div>

    <!-- Actieve filters tonen onder de filter-box -->
    <div class="active-filters" id="active-filters" aria-live="polite"></div>

</form>

<?php do_action('job_manager_job_filters_after', $atts); ?>

<script>
document.addEventListener("DOMContentLoaded", () => {
  const form = document.querySelector("form.job_filters");
  if (!form) return;

  const wpjmFilter = () => {
    if (window.job_manager_job_filters && typeof window.job_manager_job_filters.filter_jobs === "function") {
      window.job_manager_job_filters.filter_jobs();
    } else {
      form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
    }
  };

  const debounce = (fn, delay = 250) => {
    let t;
    return () => { clearTimeout(t); t = setTimeout(fn, delay); };
  };

  const kw = document.querySelector("#search_keywords");
  const loc = document.querySelector("#search_location");
  if (kw) kw.addEventListener("input", debounce(wpjmFilter, 250));
  if (loc) loc.addEventListener("input", debounce(wpjmFilter, 250));

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    wpjmFilter();
  });

  const closeAll = () => {
    document.querySelectorAll(".dr-select.active").forEach((el) => {
      el.classList.remove("active");
      const searchInput = el.querySelector(".dr-search-input");
      if (searchInput) {
        searchInput.value = "";
        el.querySelectorAll(".dr-option").forEach((option) => {
          option.style.display = "";
        });
      }
    });
  };

  // Active filters (chips onder de filters)
  const activeFiltersEl = document.getElementById("active-filters");

  const renderActiveFilters = () => {
    if (!activeFiltersEl) return;
    activeFiltersEl.innerHTML = "";

    const selects = document.querySelectorAll("select.js-custom-select");
    selects.forEach((select) => {
      const selectedOptions = [...select.options].filter(o => o.selected && o.value !== "");
      selectedOptions.forEach((opt) => {
        const chip = document.createElement("span");
        chip.className = "active-filter";
        chip.innerHTML = `<span class="active-filter-text"></span><button type="button" class="active-filter-x" aria-label="Verwijder filter">×</button>`;
        chip.querySelector(".active-filter-text").textContent = opt.textContent;

        chip.querySelector(".active-filter-x").addEventListener("click", (e) => {
          e.preventDefault();
          opt.selected = false;
          select.dispatchEvent(new Event("change", { bubbles: true }));
        });

        activeFiltersEl.appendChild(chip);
      });
    });

    activeFiltersEl.style.display = activeFiltersEl.children.length ? "flex" : "none";
  };

  const buildSelect = (select) => {
    const isMultiple = select.multiple === true;
    const forceMode = select.dataset.mode;
    const isSingle = forceMode === "single" ? true : !isMultiple;
    const placeholder = select.dataset.placeholder || "Selecteer";

    const wrap = document.createElement("div");
    wrap.className = "dr-select-wrap";
    select.parentNode.insertBefore(wrap, select);
    wrap.appendChild(select);
    select.classList.add("dr-hidden-select");

    const root = document.createElement("div");
    root.className = "dr-select";
    root.dataset.type = isSingle ? "single" : "multi";

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "dr-select-btn";
    btn.innerHTML = `
      <span class="dr-btn-content">
        <span class="dr-placeholder">${placeholder}</span>
        <span class="dr-tags" aria-hidden="true"></span>
      </span>
      <span class="dr-actions">
        <button type="button" class="dr-clear" aria-label="Wis selectie" title="Wis selectie">×</button>
        <span class="dr-chev" aria-hidden="true"></span>
      </span>
    `;

    const clearBtn = btn.querySelector(".dr-clear");
    clearBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      e.preventDefault();
      [...select.options].forEach(o => o.selected = false);
      renderState();
      select.dispatchEvent(new Event("change", { bubbles: true }));
    });

    const list = document.createElement("div");
    list.className = "dr-options";
    list.setAttribute("role", "listbox");
    if (!isSingle) list.setAttribute("aria-multiselectable", "true");

    let searchInput = null;
    if (!isSingle) {
      const searchWrap = document.createElement("div");
      searchWrap.className = "dr-search";
      searchWrap.innerHTML = `<input type="text" class="dr-search-input" placeholder="Zoek in ${placeholder.toLowerCase()}">`;
      searchInput = searchWrap.querySelector(".dr-search-input");
      list.appendChild(searchWrap);
    }

    const makeOptionRow = (opt) => {
      const row = document.createElement("div");
      row.className = "dr-option";
      row.dataset.value = opt.value;
      row.setAttribute("role", "option");
      row.setAttribute("aria-selected", opt.selected ? "true" : "false");
      row.innerHTML = `<span class="dr-option-text"></span>`;
      row.querySelector(".dr-option-text").textContent = opt.textContent;

      const syncSelected = () => {
        row.classList.toggle("is-selected", opt.selected);
        row.setAttribute("aria-selected", opt.selected ? "true" : "false");
      };
      syncSelected();

      row.addEventListener("click", (e) => {
        e.preventDefault();
        if (opt.disabled) return;
        if (isSingle) {
          [...select.options].forEach(o => o.selected = false);
          opt.selected = true;
          closeAll();
          root.classList.remove("active");
        } else {
          opt.selected = !opt.selected;
        }
        renderState();
        select.dispatchEvent(new Event("change", { bubbles: true }));
      });

      return { row, syncSelected };
    };

    const optionRows = [];
    [...select.options].forEach((opt) => {
      if (isSingle && opt.value === "") return;
      const { row, syncSelected } = makeOptionRow(opt);
      optionRows.push({ opt, row, syncSelected });
      list.appendChild(row);
    });

    const filterOptionRows = () => {
      if (!searchInput) return;
      const term = searchInput.value.trim().toLowerCase();
      optionRows.forEach(({ row, opt }) => {
        row.style.display = opt.textContent.toLowerCase().includes(term) ? "" : "none";
      });
    };

    if (searchInput) {
      searchInput.addEventListener("input", filterOptionRows);
      searchInput.addEventListener("click", (e) => e.stopPropagation());
      searchInput.addEventListener("keydown", (e) => e.stopPropagation());
    }

    const tagsEl = btn.querySelector(".dr-tags");
    const placeholderEl = btn.querySelector(".dr-placeholder");

    const renderState = () => {
      optionRows.forEach(({ opt, syncSelected }) => syncSelected());
      const selectedOptions = [...select.options].filter(o => o.selected && o.value !== "");
      tagsEl.innerHTML = "";

      if (selectedOptions.length === 0) {
        placeholderEl.style.display = "inline";
        tagsEl.style.display = "none";
        clearBtn.style.display = "none";
        return;
      }

      clearBtn.style.display = "inline-flex";

      if (isSingle) {
        placeholderEl.textContent = selectedOptions[0].textContent;
        placeholderEl.style.display = "inline";
        tagsEl.style.display = "none";
        return;
      }

      // MULTI: placeholder tonen (geen chips in knop)
      placeholderEl.textContent = placeholder;
      placeholderEl.style.display = "inline";
      tagsEl.style.display = "none";
      tagsEl.innerHTML = "";
    };

    renderState();

    btn.addEventListener("click", (e) => {
      if (e.target.closest(".dr-clear")) return;
      e.preventDefault();
      const wasOpen = root.classList.contains("active");
      closeAll();
      if (!wasOpen) {
        root.classList.add("active");
        if (searchInput) {
          searchInput.value = "";
          filterOptionRows();
          window.setTimeout(() => searchInput.focus(), 10);
        }
      }
    });

    select.addEventListener("change", () => {
      renderState();
      renderActiveFilters();
      wpjmFilter();
    });

    root.appendChild(btn);
    root.appendChild(list);
    wrap.appendChild(root);
  };

  document.querySelectorAll("select.js-custom-select").forEach(buildSelect);
  renderActiveFilters();

  document.addEventListener("click", (e) => {
    if (!e.target.closest(".dr-select")) closeAll();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAll();
  });
});
</script>

<style>
/*
 * Alle regels zijn gescoped op .dr-job-filters zodat de globale Elementor-styling
 * (.elementor-kit-N a/h2/button/input) deze elementen niet overschrijft.
 */
.dr-job-filters {
  width: 100vw;
  position: relative;
  left: 50%;
  right: 50%;
  margin-left: -50vw;
  margin-right: -50vw;
  margin-top: 0;
  margin-bottom: 0;
  min-height: 300px;
  padding: 56px 0;
  background: #FEEAD5;
  box-shadow: none;
  border: none;
  border-bottom: 1px solid #FCAF2B;
  border-radius: 0;
  box-sizing: border-box;
}

.dr-job-filters .filter-header,
.dr-job-filters .search-basic,
.dr-job-filters .filter-box,
.dr-job-filters .active-filters {
  max-width: 1200px;
  margin-left: auto !important;
  margin-right: auto !important;
}

.dr-job-filters .filter-header {
  padding: 0 24px 18px !important;
}

.dr-job-filters .dr-filters__title {
  margin: 0;
  font-family: 'Work Sans', sans-serif;
  font-size: 28px;
  line-height: 1.1;
  font-weight: 700;
  color: #2C2C31;
}

.dr-job-filters .dr-filters__intro {
  margin: 10px 0 0;
  font-family: 'Work Sans', sans-serif;
  font-size: 15px;
  color: #2C2C31;
}

.dr-job-filters .dr-filters__alert-link {
  color: #2C2C31;
  font-weight: 400;
  text-decoration: underline;
  font-family: 'Work Sans', sans-serif;
}

.dr-job-filters .dr-filters__alert-link:hover {
  color: #E09B1A;
  text-decoration: underline;
}

.dr-job-filters .search-basic {
  display: flex;
  gap: 16px;
  padding: 0 24px;
}

.dr-job-filters .search_location,
.dr-job-filters .search_keywords {
  flex-basis: 50%;
  max-width: 50%;
  display: flex;
  align-items: center;
  position: relative;
}

/* Extra specificiteit: Elementor stijlt inputs met input:not([type=button]):not([type=submit]) */
form.dr-job-filters input.dr-filters__input[type="text"] {
  width: 100%;
  padding: 13px 14px 13px 40px;
  font-size: 15px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background-color: #ffffff;
  color: #2C2C31;
  box-shadow: none;
  transition: border-color .2s ease;
  font-family: 'Work Sans', sans-serif;
  font-weight: 400;
}

form.dr-job-filters input.dr-filters__input[type="text"]:focus {
  outline: none;
  border-color: #FCAF2B;
}

.dr-job-filters .dr-filters__input::placeholder {
  color: #7c7c7c;
  font-size: 15px !important;
  font-style: italic;
}

.dr-job-filters .search_keywords::before,
.dr-job-filters .search_location::before {
  content: '';
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  width: 18px;
  height: 18px;
  background-repeat: no-repeat;
  background-size: contain;
  pointer-events: none;
}

.dr-job-filters .search_keywords::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232C2C31' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Ccircle cx='11' cy='11' r='8'/%3E%3Cpath d='m21 21-4.35-4.35'/%3E%3C/svg%3E");
}

.dr-job-filters .search_location::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232C2C31' stroke-width='2.2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 2a7 7 0 0 1 7 7c0 5.25-7 13-7 13S5 14.25 5 9a7 7 0 0 1 7-7z'/%3E%3Ccircle cx='12' cy='9' r='2.5'/%3E%3C/svg%3E");
}

.dr-job-filters .filter-box {
  display: flex;
  flex-wrap: wrap;
  gap: 16px;
  padding: 16px 24px 0;
}

.dr-job-filters .filter-box > div {
  flex: 0 0 auto !important;
  min-width: 0 !important;
}

select.dr-hidden-select {
  position: absolute !important;
  left: -9999px !important;
  width: 1px !important;
  height: 1px !important;
  opacity: 0 !important;
}

.dr-select-wrap,
.dr-select {
  position: relative;
  width: auto;
  display: inline-block;
}

.dr-job-filters .dr-select-btn {
  width: auto;
  display: inline-flex;
  align-items: center;
  justify-content: space-between;
  white-space: nowrap;
  border-radius: 999px;
  border: 1px solid #e0e0e0 !important;
  background-color: #ffffff !important;
  padding: 12px;
  min-height: 44px;
  line-height: 1.2;
  text-transform: none;
  letter-spacing: normal;
  cursor: pointer;
  user-select: none;
  font-family: 'Work Sans', sans-serif;
  font-weight: 700;
  font-size: 16px;
  color: #111111 !important;
}

.dr-btn-content {
  display: flex;
  align-items: center;
  gap: 10px;
  flex-wrap: wrap;
  min-width: 0;
}

.dr-placeholder {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  font-family: 'Work Sans', sans-serif;
  font-weight: 700;
  color: #2C2C31;
  font-size: 15px;
}

.dr-tags {
  display: none;
  gap: 6px;
  align-items: center;
  flex-wrap: wrap;
}

.dr-actions {
  display: inline-flex;
  align-items: center;
  gap: 0 !important;
  margin-left: 10px;
}

.dr-clear {
  display: none !important;
}

.dr-chev {
  width: 10px;
  height: 10px;
  border-right: 2px solid #111;
  border-bottom: 2px solid #111;
  transform: rotate(45deg);
  transition: transform .2s ease;
}

.dr-select.active .dr-chev {
  transform: rotate(-135deg);
}

.dr-options {
  display: none;
  position: absolute;
  left: 0;
  right: auto;
  width: max-content;
  min-width: 100%;
  margin-top: 10px;
  background: #fff;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 8px;
  max-height: 280px;
  overflow: auto;
  z-index: 9999;
}

.dr-select.active .dr-options {
  display: block;
}

.dr-search {
  position: sticky;
  top: 0;
  z-index: 2;
  background: #ffffff;
  padding: 4px 4px 10px;
}

form.dr-job-filters input.dr-search-input[type="text"] {
  width: 100%;
  min-width: 220px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 11px 12px;
  font-family: 'Work Sans', sans-serif;
  font-size: 14px;
  color: #2C2C31;
  background: #ffffff;
  box-sizing: border-box;
}

.dr-search-input::placeholder {
  color: #7c7c7c;
}

form.dr-job-filters input.dr-search-input[type="text"]:focus {
  outline: none;
  border-color: #FCAF2B;
}

.dr-option {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 10px 12px;
  border-radius: 8px;
  cursor: pointer;
}

.dr-option:hover {
  background: #f8f8f8;
}

.dr-option.is-selected {
  background: #FEEAD5;
}

.dr-option.is-selected .dr-option-text {
  color: #2C2C31;
  font-weight: 700;
}

.dr-option-text {
  font-family: 'Work Sans', sans-serif;
  font-weight: 600;
  color: #2C2C31;
}

/* Filter-knop iconen */
.dr-job-filters .job_type .dr-select-btn,
.dr-job-filters .job_sector .dr-select-btn,
.dr-job-filters .job_regio .dr-select-btn,
.dr-job-filters .job_name .dr-select-btn,
.dr-job-filters .job_company .dr-select-btn {
  padding-left: 38px !important;
  position: relative;
}

.job_type .dr-select-btn::before,
.job_sector .dr-select-btn::before,
.job_regio .dr-select-btn::before,
.job_name .dr-select-btn::before,
.job_company .dr-select-btn::before {
  content: '';
  position: absolute;
  left: 12px;
  top: 50%;
  transform: translateY(-50%);
  width: 16px;
  height: 16px;
  background-repeat: no-repeat;
  background-size: contain;
  pointer-events: none;
  flex-shrink: 0;
}

/* Briefcase - Dienstverband */
.job_type .dr-select-btn::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232C2C31' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='2' y='7' width='20' height='14' rx='2'/%3E%3Cpath d='M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2'/%3E%3Cline x1='12' y1='12' x2='12' y2='17'/%3E%3Cline x1='9.5' y1='14.5' x2='14.5' y2='14.5'/%3E%3C/svg%3E");
}

/* Grid - Sector */
.job_sector .dr-select-btn::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232C2C31' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Crect x='3' y='3' width='7' height='7'/%3E%3Crect x='14' y='3' width='7' height='7'/%3E%3Crect x='3' y='14' width='7' height='7'/%3E%3Crect x='14' y='14' width='7' height='7'/%3E%3C/svg%3E");
}

/* Map pin - Regio */
.job_regio .dr-select-btn::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232C2C31' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M12 2a7 7 0 0 1 7 7c0 5.25-7 13-7 13S5 14.25 5 9a7 7 0 0 1 7-7z'/%3E%3Ccircle cx='12' cy='9' r='2.5'/%3E%3C/svg%3E");
}

/* Person - Beroep */
.job_name .dr-select-btn::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232C2C31' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2'/%3E%3Ccircle cx='12' cy='7' r='4'/%3E%3C/svg%3E");
}

/* Building - Organisatie */
.job_company .dr-select-btn::before {
  background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='none' stroke='%232C2C31' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z'/%3E%3Cpolyline points='9 22 9 12 15 12 15 22'/%3E%3C/svg%3E");
}

.dr-job-filters .dr-select-btn:hover,
.dr-job-filters .dr-select-btn:focus {
  outline: none;
  background-color: #ffffff !important;
  border-color: #FCAF2B !important;
  color: #111111 !important;
}

.dr-job-filters .active-filters {
  display: none;
  flex-wrap: wrap;
  gap: 10px;
  margin: 14px 24px 0 !important;
}

span.active-filter {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  background: #ffffff;
  border: 1px solid rgba(0, 0, 0, 0.12);
  border-radius: 999px;
  padding: 8px 12px;
  font-size: 16px;
  color: #111;
  font-weight: 700 !important;
  cursor: pointer;
}

.active-filter:hover {
  border-color: #FCAF2B;
}

.active-filter-text {
  color: #2C2C31;
}

.dr-job-filters .active-filter-x {
  color: #FCAF2B;
  font-weight: 700;
  font-size: 20px;
  line-height: 1;
  margin-left: 6px;
  padding: 0;
  background: none;
  border: none;
  cursor: pointer;
}

.dr-job-filters .active-filter-x:hover,
.dr-job-filters .active-filter-x:focus {
  color: #E09B1A;
  background: none;
}

@media (max-width: 960px) {
  form.job_filters {
    width: 100% !important;
    position: relative !important;
    left: 0 !important;
    right: auto !important;
    margin: 0 !important;
    padding: 24px 0 !important;
  }

  .dr-job-filters .filter-header {
    padding: 0 16px 12px !important;
  }

  .dr-job-filters .search-basic {
    flex-direction: column;
    gap: 10px;
    padding: 0 16px !important;
  }

  .dr-job-filters .search_location,
  .dr-job-filters .search_keywords {
    max-width: 100%;
    flex-basis: 100%;
    width: 100%;
  }

  .dr-job-filters .filter-box {
    flex-direction: column;
    padding: 12px 16px 0 !important;
    gap: 10px;
  }

  .dr-job-filters .filter-box > div,
  .dr-job-filters .dr-select-wrap,
  .dr-job-filters .dr-select,
  .dr-job-filters .dr-select-btn {
    width: 100% !important;
  }

  .dr-options {
    width: 100% !important;
    min-width: 0 !important;
    left: 0 !important;
    right: 0 !important;
  }

  .dr-job-filters .active-filters {
    margin: 12px 16px 0 !important;
  }
}
</style>
