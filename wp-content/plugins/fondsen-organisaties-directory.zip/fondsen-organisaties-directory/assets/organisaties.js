(function ($) {
  "use strict";

  $(document).on("click", "#fondsen-org-load-more", function (e) {
    e.preventDefault();

    if (typeof FOND_DIR === "undefined") {
      console.error("FOND_DIR ontbreekt. Script is niet gelocalized.");
      return;
    }

    const $btn = $(this);
    const $wrap = $("#fondsen-org-results");
    const $form = $("#fondsen-org-filter-form");

    const page = parseInt($btn.data("page") || 1, 10);
    const perPage = parseInt($btn.data("per-page") || 30, 10);

    // Lees huidige filters uit form (moet dus bestaan)
    const search = ($form.find('input[name="org_search"]').val() || "").trim();

    // Multi selects: name="org_sector[]" / name="org_type[]"
    const sector = $form.find('select[name="org_sector[]"]').val() || [];
    const type = $form.find('select[name="org_type[]"]').val() || [];

    $btn.prop("disabled", true).addClass("is-loading");

    $.ajax({
      url: FOND_DIR.ajax_url,
      method: "POST",
      dataType: "json",
      data: {
        action: "fondsen_org_dir_load_more",
        nonce: FOND_DIR.nonce,
        page: page,
        per_page: perPage,
        org_search: search,
        org_sector: sector,
        org_type: type
      }
    })
      .done(function (resp) {
        if (!resp || resp.success !== true || !resp.data) {
          console.error("Onverwachte response:", resp);
          return;
        }

        // ✅ let op: resp.data.html (niet resp.html)
        if (resp.data.html) {
          $wrap.append(resp.data.html);
        }

        // next page
        $btn.data("page", resp.data.next_page || (page + 1));

        // hide if no more
        if (!resp.data.has_more) {
          $btn.hide();
        }
      })
      .fail(function (xhr) {
        console.error("AJAX error:", xhr.status, xhr.responseText);
      })
      .always(function () {
        $btn.prop("disabled", false).removeClass("is-loading");
      });
  });

})(jQuery);
