<?php
if ( ! defined('ABSPATH') ) exit;

/** @var WP_Query $query */
$query = $context['query'];
?>

<style>
.org-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 22px;
    width: 1050px;
    max-width: calc(100% - 24px);
    margin: 0 auto;
}

@media (max-width: 900px) {
    .org-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}
@media (max-width: 600px) {
    .org-grid { grid-template-columns: 1fr; }
}

.org-card {
    border: 1px solid #E4E7EC;
    border-radius: 5px;
    background: #fff;
    overflow: hidden;
    box-shadow: 0 10px 40px -5px rgba(0,0,0,.15);
    display: flex;
    flex-direction: column;
    min-height: 100%;
}

.org-card__img {
    width: 100%;
    aspect-ratio: 16 / 9;
    background: #F2F4F7;
    overflow: hidden;
}

.org-card__img img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
}

.org-card__body {
    padding: 14px 14px 16px;
}

.org-card__title {
    margin: 0 0 10px;
    font-size: 18px;
    line-height: 1.25;
    font-family: Poppins ,sans-serif;
    font-weight: 600;
    color: #333333;
}

.org-card__title a {
    text-decoration: none;
    color: #101828;
}

.org-card__excerpt {
    margin: 0;
    font-size: 14.5px;
    line-height: 1.45;
    color: #475467;
}
</style>

<?php if (!defined('ABSPATH')) exit; ?>

<div class="fod-org-grid-wrap">
  <div class="fod-org-grid" id="fod-org-grid"
       data-page="1"
       data-max-pages="<?php echo (int) ($data['max_pages'] ?? 1); ?>"
       data-per-page="<?php echo (int) ($data['per_page'] ?? 30); ?>">
    <?php
    if (!empty($data['posts'])) :
      global $post;
      foreach ($data['posts'] as $post) :
        setup_postdata($post);
        include __DIR__ . '/organisaties-grid-item.php';
      endforeach;
      wp_reset_postdata();
    else :
      echo '<p>Geen organisaties gevonden.</p>';
    endif;
    ?>
  </div>

  <?php if ( (int) ($data['max_pages'] ?? 1) > 1 ) : ?>
    <div class="fod-org-loadmore-wrap">
      <button type="button" class="fod-org-loadmore" id="fod-org-loadmore">
        Laad meer organisaties
      </button>
    </div>
  <?php endif; ?>
</div>